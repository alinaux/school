/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arichie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/03 00:40:13 by arichie           #+#    #+#             */
/*   Updated: 2021/03/03 02:42:55 by arichie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H

#include <unistd.h>

void	ft_putstr(char *str);
int		ft_atoi(char *str);
int		plus(int a, int b);
int		minus(int a, int b);
int		div(int a, int b);
int		mult(int a, int b);
int		mod(int a, int b);

#endif
