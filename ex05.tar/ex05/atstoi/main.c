/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arichie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/03 00:42:54 by arichie           #+#    #+#             */
/*   Updated: 2021/03/03 03:17:02 by arichie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		plus(int a, int b);
int		minus(int a, int b);
int		div(int a, int b);
int		mult(int a, int b);
int		mod(int a, int b);

int		oper(char c)
{
	if (c == '+')
		return (0);
	else if (c == '-')
		return (1);
	else if (c == '/')
		return (2);
	else if (c == '*')
		return (3);
	else if (c == '%')
		return (4);
	return (5);
}

int		res(char *x, char ator, char *y)
{
	int (*f[5]) (int a, int b);
	int i;
	int j;

	f[0] = plus;
	f[1] = minus;
	f[2] = div;
	f[3] = mult;
	f[4] = mod;
	if (oper(ator) == 5)
		return (0);
	i = ft_atoi(x);
	j = ft_atoi(y);
	return (f[oper(ator)](i, j));
}

int		main(int argc, char **argv)
{

	if (argc == 4)
	{
		return (res(argv[1], *argv[2], argv[3]));
	}
	write(1, " ", 1);
	return (0);
}
