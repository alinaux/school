/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   func.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: arichie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/02 22:28:21 by arichie           #+#    #+#             */
/*   Updated: 2021/03/03 02:35:23 by arichie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);
int		ft_atoi(char *str);

int		plus(int a, int b)
{	
	return (a + b);
}

int		minus(int a, int b)
{
	return (a - b);
}

int		div(int a, int b)
{
	if (b == 0)
		ft_putstr("Stop : division by zero\n");
	return (a / b);
}

int		mult(int a, int b)
{
	return (a * b);
}

int		mod(int a, int b)
{
	if (b == 0)
		ft_putstr("Stop : modulo by zero\n");
	return (a % b);
}
